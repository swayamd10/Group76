package com.example.safecheck;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.safecheck.adapter.SafetyAdapter;
import com.example.safecheck.model.SafetyViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setBackgroundDrawableResource(android.R.color.white);
        window.getDecorView().setBackgroundColor(Color.WHITE);

        setContentView(R.layout.activity_main);

        getWindow().getDecorView().setBackgroundColor(Color.WHITE);
        findViewById(R.id.main).setBackgroundColor(Color.WHITE);

//        RecyclerView with a vertical list layout
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setBackgroundColor(Color.WHITE);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

//        enpty first and then populated by the adapter
        SafetyAdapter adapter = new SafetyAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        SafetyViewModel viewModel = new ViewModelProvider(this).get(SafetyViewModel.class);
        viewModel.getAllSafetyChecks().observe(this, data -> {
            adapter.updateData(data);
        });

        // floating button opens AddCheckActivity(now this will ge a plus sign)
        FloatingActionButton addCheckBtn = findViewById(R.id.addCheckBtn);
        addCheckBtn.setOnClickListener(v -> {
            startActivity(new Intent(this, AddCheckActivity.class));
        });
    }
}
package com.example.safecheck.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.example.safecheck.DetailActivity;
import com.example.safecheck.R;
import com.example.safecheck.database.SafeCheckDatabase;
import com.example.safecheck.model.SafetyCheck;
import com.example.safecheck.model.SafetyViewModel;

import java.util.List;

//Created SafetyAdapter with SafetyViewHolder.
// Adapter for the main safety checks list on MainActivity
public class SafetyAdapter extends RecyclerView.Adapter<SafetyAdapter.SafetyViewHolder> {
    @NonNull
    @Override
    public SafetyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_safety_check, parent, false);
        return new SafetyViewHolder(itemView);
//        - same as defects adapter here i am inflatig the Row layout & return a ViewHolder holding that view.
    }

    @Override
    public void onBindViewHolder(@NonNull SafetyViewHolder holder, int position) {
//       here we will get the safety check for this row
//        then set date and vehicle reg text
//        and finally  clicking a row opens DetailActivity and passes the checkId

        SafetyCheck current = listData.get(position);
        holder.date.setText("Date: "+current.getDate());
        holder.vehicleRegistration.setText("Vehicle Reg: "+current.getVehicleRegistration());

        SafeCheckDatabase db = SafeCheckDatabase.getINSTANCE(holder.itemView.getContext());
        int defCOunt = db.defectDao().getDefectCount(current.getCheckId());
        holder.defaultCount.setText(defCOunt + (defCOunt == 1 ? " Defect" : " Defects" +" With Driver:  "+ current.getDriverName()+" / "+current.getOverallStatus()));
//        holder.defaultCount.setText("Driver:  "+ current.getDriverName()+" / "+current.getOverallStatus());

//        gets the current item using position and set the data and click listener.
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(holder.itemView.getContext(), DetailActivity.class);
            intent.putExtra("checkId", current.getCheckId());
            holder.itemView.getContext().startActivity(intent);
        });

        holder.deleteBtn.setOnClickListener(v->{
            FragmentActivity activity = (FragmentActivity) holder.itemView.getContext();
            SafetyViewModel vm = new ViewModelProvider(activity).get(SafetyViewModel.class);
            vm.deleteSafetyCheck(current);
        });
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }
//    - return the size of the list.

    private List<SafetyCheck> listData;
    public SafetyAdapter(List<SafetyCheck> listData){
        this.listData = listData;
    }

    public static class SafetyViewHolder extends RecyclerView.ViewHolder{
        TextView date;
        TextView vehicleRegistration;
        TextView defaultCount;
        Button deleteBtn;

        public SafetyViewHolder(View view){
            super(view);
            date = view.findViewById(R.id.date);
            vehicleRegistration = view.findViewById(R.id.vehicleRegistration);
            defaultCount = view.findViewById(R.id.defaultCount);
            deleteBtn=view.findViewById(R.id.deleteBtn);
        }
//        super(view) is used to handles the row as a whole, and view.findViewById() is used ti handles what's inside the row.
    }


    public void updateData(List<SafetyCheck> newData){
        this.listData = newData;
        notifyDataSetChanged();
    }


}

package com.example.safecheck;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.safecheck.adapter.DefectsAdapter;
import com.example.safecheck.model.Defect;
import com.example.safecheck.model.SafetyViewModel;

import java.util.ArrayList;
import java.util.List;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawableResource(android.R.color.white);
        setContentView(R.layout.activity_detail);

        int checkId = getIntent().getIntExtra("checkId", -1);

        SafetyViewModel viewModel = new ViewModelProvider(this).get(SafetyViewModel.class);

        TextView textDate = findViewById(R.id.textDate);
        TextView textVehicle = findViewById(R.id.textVehicle);
        TextView textDriver = findViewById(R.id.textDriver);
        TextView textStatus = findViewById(R.id.textStatus);

        viewModel.getSafetyCheckItemById(checkId).observe(this, safetyItem -> {
            if (safetyItem != null) {
                textDate.setText("Date: " + safetyItem.getDate());
                textVehicle.setText("Vehicle: " + safetyItem.getVehicleRegistration());
                textDriver.setText("Driver: " + safetyItem.getDriverName());
                textStatus.setText("Status: " + safetyItem.getOverallStatus());
            }
        });

        final List<Defect> currentDefects = new ArrayList<>();

        RecyclerView recyclerView = findViewById(R.id.defectsList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        viewModel.getDefectById(checkId).observe(this, list -> {
            currentDefects.clear();
            if (list != null) {
                currentDefects.addAll(list);
            }
            recyclerView.setAdapter(new DefectsAdapter(currentDefects));
        });

        Button btnEmail = findViewById(R.id.required);
        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String vehicleReg = textVehicle.getText().toString();
                String emailSubject = "Safety Defect Report: " + vehicleReg;

                StringBuilder emailBody = new StringBuilder();
                for (Defect defect : currentDefects) {
                    emailBody.append("- ").append(defect.getDescription()).append("\n");
                }
                if (emailBody.length() == 0) {
                    emailBody.append("No defects recorded.");
                }

                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse("mailto:"));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, emailSubject);
                emailIntent.putExtra(Intent.EXTRA_TEXT, emailBody.toString());

                try {
                    startActivity(Intent.createChooser(emailIntent, "Send via Email"));
                } catch (android.content.ActivityNotFoundException e) {
                    Toast.makeText(v.getContext(), "No Email App Found!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //code for event listner that allows to add defects using the buttoin
        Button addDefectBtn = findViewById(R.id.addDefectBtn);
        addDefectBtn.setOnClickListener(v -> {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Add Defect");


            android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
            layout.setOrientation(android.widget.LinearLayout.VERTICAL);
            layout.setPadding(50, 20, 50, 20);
            android.widget.EditText descEditText = new android.widget.EditText(this);
            descEditText.setHint("Defect Description(for eg cracked mirror)");
            layout.addView(descEditText);


            String[] severities = {"Low", "High"};
            android.widget.Spinner severitySpinner = new android.widget.Spinner(this);
            android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(this, android.R.layout.simple_spinner_item, severities);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            severitySpinner.setAdapter(adapter);
            layout.addView(severitySpinner);
            builder.setView(layout);

            builder.setPositiveButton("Add", (dialog, which) -> {
                String desc = descEditText.getText().toString().trim();
                if (!desc.isEmpty()) {
                    Defect defect = new Defect(checkId, desc, severitySpinner.getSelectedItem().toString());
                    viewModel.insertDefect(defect);
                } else {
                    Toast.makeText(this, "Enter a defect description", Toast.LENGTH_SHORT).show();
                }
            });
            builder.setNegativeButton("Cancel",null );
            builder.show();
        });
    }
}
package com.example.safecheck.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.safecheck.model.Defect;

import java.util.List;

// DAO interface for defect database operations
@Dao
public interface DefectDao {
//    basically this get all defects linked to a specific safety checkby using the id
//    thenthe next step is insert and then count how many defects belong to that row
    @Query("SELECT * FROM defects WHERE checkId = :id")
    LiveData<List<Defect>> getDefectById(int id);
    @Insert
    void insertDefect(Defect defect);

    @Query("SELECT COUNT(*) FROM defects WHERE checkId = :id")
    int getDefectCount(int id);
}

package com.example.safecheck.model;

import android.app.Activity;
import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.safecheck.repository.SafetyRepo;

import java.util.List;

public class SafetyViewModel extends AndroidViewModel {
    private SafetyRepo repo;
    private LiveData<List<SafetyCheck>> allSafetyChecks;

    public SafetyViewModel(Application application){
        super(application);
        repo = new SafetyRepo(application);
        allSafetyChecks = repo.getAllSafetyChecks();
    }
    public LiveData<List<SafetyCheck>> getAllSafetyChecks() {
        return allSafetyChecks;
    }
//    - Main & Detail Activity get their data through LiveData and when data change it automatically updates the UI.
    public LiveData<List<Defect>> getDefectById(int id){
        return repo.getDefectByCheckId(id);
    }

    public LiveData<SafetyCheck> getSafetyCheckItemById(int id){
        return repo.getSafetyCheckItemById(id);
    }

    public void insertSafetyCheck(SafetyCheck safetyCheck){
        repo.insertSafetyCheck(safetyCheck);
    }
    public void deleteSafetyCheck(SafetyCheck safetyCheck){
        repo.deleteSafetyCheck(safetyCheck);
    }
    public void insertSafetyCheckWithDefects(SafetyCheck safetyCheck, List<Defect> defects) {
        repo.insertSafetyCheckWithDefects(safetyCheck, defects);
    }

    public void insertDefect(Defect defect) {
        repo.insertDefect(defect);
    }
}

package com.example.safecheck.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.safecheck.dao.DefectDao;
import com.example.safecheck.dao.SafetyCheckDao;
import com.example.safecheck.database.SafeCheckDatabase;
import com.example.safecheck.model.Defect;
import com.example.safecheck.model.SafetyCheck;
import com.example.safecheck.model.SafetyCheckWithDefects;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SafetyRepo {
//    private MutableLiveData<List<String>> listMutableLiveData = new MutableLiveData<>();
//
//    public LiveData<List<String>> getLiveDataList(){
//        return listMutableLiveData;
//    }
    private SafetyCheckDao safetyCheckDao;
    private DefectDao defectDao;
    private LiveData<List<SafetyCheck>> allSafetyCheck;

    private ExecutorService executorService; //this just runs database and writes on the background thread and mentioned in part 3

    public SafetyRepo(Context context){
        SafeCheckDatabase db = SafeCheckDatabase.getINSTANCE(context);
        safetyCheckDao=db.safetyCheckDao();
        defectDao=db.defectDao();
        allSafetyCheck=safetyCheckDao.getAllSafetyChecks();
        executorService= Executors.newSingleThreadExecutor();
    }
    public LiveData<List<SafetyCheck>>getAllSafetyChecks(){
        return  allSafetyCheck;
    }

    public void insertSafetyCheck(SafetyCheck safetyCheck){
        executorService.execute(()->safetyCheckDao.insertSafetyCheck(safetyCheck));
    }

    //insert a safetycheck first then insrert all its Defects here
    public void insertSafetyCheckWithDefects(SafetyCheck safetyCheck, List<Defect>defects){
        executorService.execute(()->{
            long newId= safetyCheckDao.insertSafetyCheck(safetyCheck);
            for(Defect defect : defects){
                defect.setCheckId((int) newId);
                defectDao.insertDefect(defect);
            }
        });
    }

    //Deletinbg a safetycheck(and then cascade will deletes its defetecs automatically)
    public  void deleteSafetyCheck(SafetyCheck safetyCheck){
        executorService.execute(()-> safetyCheckDao.deleteSafetyCheck(safetyCheck));

    }

    //here we are accessing all checks and then returning LiveData so that UI can update automatically
    public LiveData<SafetyCheck> getSafetyCheckItemById(int id){
        return safetyCheckDao.getSafetyCheckItemById(id);
    }

    //here we will get one check with all its defects which is called from background thread in ViewModel - for timebeing doesnt do anything
    public SafetyCheckWithDefects getSafetyCheckWithDefects(int id){
        return safetyCheckDao.getSafetyCheckWithDefects(id);
    }
    public LiveData<List<Defect>> getDefectByCheckId(int id){
        return defectDao.getDefectById(id);
    }

//    public void insertSafetyCheck(SafetyCheck safetyCheck){
//        executorService.execute(() ->{
//            safetyCheckDao.insertSafetyCheck(safetyCheck);
//        });
//    }

    public void insertDefect(Defect defect) {
        executorService.execute(() -> {
            defectDao.insertDefect(defect);
        });
    }
}

package com.example.safecheck;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.safecheck.model.Defect;
import com.example.safecheck.model.SafetyCheck;
import com.example.safecheck.model.SafetyViewModel;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AddCheckActivity extends AppCompatActivity {

    private final List<Defect> pendingDefects = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawableResource(android.R.color.white);
        setContentView(R.layout.activity_add_check);

        //adding a date sectionn so that the user will be able to pick date and then other necessary fields.
        EditText editDate = findViewById(R.id.editDate);
        editDate.setFocusable(false);
        editDate.setClickable(true);
        editDate.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) -> {
                editDate.setText(day + "/" + (month + 1) + "/" + year);
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
        });
        EditText editVehicle = findViewById(R.id.editVehicle);
        EditText editDriver = findViewById(R.id.editDriver);
        Spinner editStatus = findViewById(R.id.editStatus);
        EditText editDefectDesc = findViewById(R.id.editDefectDescription);
        Spinner editDefectSeverity = findViewById(R.id.editDefectSeverity);
        Button addDefectBtn = findViewById(R.id.addDefectBtn);
        TextView defectPreview = findViewById(R.id.defectPreview);
        Button saveBtn = findViewById(R.id.saveBtn);

        ArrayAdapter<String> statusOptions = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new String[]{"Pass", "Fail"});
        statusOptions.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        editStatus.setAdapter(statusOptions);

        ArrayAdapter<String> severityOptions = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new String[]{"Low", "High"});
        severityOptions.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        editDefectSeverity.setAdapter(severityOptions);

        SafetyViewModel viewModel = new ViewModelProvider(this).get(SafetyViewModel.class);

        addDefectBtn.setOnClickListener(v -> {
            String desc = editDefectDesc.getText().toString().trim();
            if (desc.isEmpty()) {
                Toast.makeText(this, "Enter a defect description", Toast.LENGTH_SHORT).show();
            } else {
                String sev = editDefectSeverity.getSelectedItem().toString();
                // checkId is 0 for now this is because the repo sets it after insert
                pendingDefects.add(new Defect(0, desc, sev));
                editDefectDesc.setText("");
                defectPreview.setText("Defects added: " + pendingDefects.size());
            }
        });

        saveBtn.setOnClickListener(v -> {
            String date = editDate.getText().toString().trim();
            String vehicle = editVehicle.getText().toString().trim();
            String driver = editDriver.getText().toString().trim();
            String status = editStatus.getSelectedItem().toString();

            if (vehicle.isEmpty()) {
                Toast.makeText(this, "Please Enter Vehicle Registration", Toast.LENGTH_SHORT).show();
            } else {
                SafetyCheck check = new SafetyCheck(date, vehicle, driver, status);
                viewModel.insertSafetyCheckWithDefects(check, pendingDefects);
                finish();
            }
        });
    }
}
package com.example.safecheck.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.safecheck.R;
import com.example.safecheck.model.Defect;

import java.util.List;

public class DefectsAdapter extends RecyclerView.Adapter<DefectsAdapter.DefectsViewHolder> {
    private List<Defect> defectsList;
    public DefectsAdapter(List<Defect> defectsList){
        this.defectsList = defectsList;
    }

    @NonNull
    @Override
    public DefectsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item_SafetyCheck = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_defects, parent, false);
        DefectsViewHolder holder = new DefectsViewHolder(item_SafetyCheck);
        return holder;
        //        this will be  inflating the Row layout & return a ViewHolder holding that view,
    }

    @Override
    public void onBindViewHolder(@NonNull DefectsViewHolder holder, int position) {
        Defect defectDetailList = defectsList.get(position);
        holder.description.setText("Defect : "+defectDetailList.getDescription());
        holder.severity.setText("Severity: "+defectDetailList.getSeverity());
        //gets the current item using position and set the data and then basically hekp in binding the data
    }

    @Override
    public int getItemCount() {
        return defectsList.size();
    }
//    - return the size of the list.

    public static class DefectsViewHolder extends RecyclerView.ViewHolder{
//        RecyclerView defectsList;
        TextView description;
        TextView severity;
        public DefectsViewHolder(View view){
            super(view);
//            defectsList = view.findViewById(R.id.defectsList);
            description = view.findViewById(R.id.description);
            severity = view.findViewById(R.id.severity);
        }
//        super(view) is used to handles the row as a whole, and view.findViewById() is used to handles what's inside the row.
//        i have changed this reclerview to text view so therefore changed the view holder
    }
}
